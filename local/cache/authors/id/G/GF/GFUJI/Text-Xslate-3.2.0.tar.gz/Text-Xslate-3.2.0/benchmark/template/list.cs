List:
<?cs each:item = data ?>
    * <?cs var:item.title ?>
    * <?cs var:item.title ?>
    * <?cs var:item.title ?>
<?cs /each ?>
